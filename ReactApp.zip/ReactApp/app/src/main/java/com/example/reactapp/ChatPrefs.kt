package com.example.reactapp

import android.content.Context

/** سنجاق، بی‌صدا و آرشیو گفتگوها */
object ChatPrefs {
    private fun p(c: Context) = c.getSharedPreferences("chats", 0)
    fun has(c: Context, list: String, k: String) = (p(c).getStringSet(list, emptySet()) ?: emptySet()).contains(k)
    fun toggle(c: Context, list: String, k: String) {
        val s = HashSet(p(c).getStringSet(list, emptySet()) ?: emptySet())
        if (!s.remove(k)) s.add(k)
        p(c).edit().putStringSet(list, s).apply()
    }
}
