package com.example.reactapp

import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView

class AppearanceActivity : Base() {
    private lateinit var holder: LinearLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val sv = ScrollView(this).apply { setBackgroundColor(pal.bg) }
        holder = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(20), dp(16), dp(24)) }
        sv.addView(holder)
        setContentView(sv)
    }

    override fun refresh() = build()

    private fun set(k: String, v: Any) { Theme.set(this, k, v); recreate() }

    private fun section(t: String) = holder.addView(tv(t, 14f, pal.mut, true).apply { setPadding(0, dp(20), 0, dp(8)) })

    private fun chips(labels: List<String>, sel: Int, pick: (Int) -> Unit) {
        val row = LinearLayout(this)
        labels.forEachIndexed { i, t ->
            row.addView(tv(t, 14f, if (i == sel) WHITE else pal.ink, true).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(12)); background = box(if (i == sel) pal.acc else pal.soft, 14)
                setOnClickListener { pick(i) }
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        holder.addView(row)
    }

    private fun build() {
        holder.removeAllViews()
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(circle(if (L.fa) "›" else "‹", box(pal.soft, 21), 42, 22f, pal.ink) { finish() })
        head.addView(tv(L.t("ظاهر", "Appearance"), 24f, pal.ink, true), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12) })
        holder.addView(head)

        section(L.t("تم", "Theme"))
        val modes = listOf("auto", "light", "dark", "black")
        chips(listOf(L.t("خودکار", "Auto"), L.t("روشن", "Light"), L.t("تیره", "Dark"), "AMOLED"), modes.indexOf(Theme.mode(this)).coerceAtLeast(0)) { set("mode", modes[it]) }

        section(L.t("رنگ اصلی", "Accent color"))
        val row = LinearLayout(this)
        Theme.accents.forEachIndexed { i, col ->
            row.addView(circle(if (i == Theme.accent(this)) "✓" else "", box(col, 22), 44, 20f, WHITE) { set("accent", i) },
                LinearLayout.LayoutParams(dp(44), dp(44)).apply { setMargins(dp(4), 0, dp(10), 0) })
        }
        holder.addView(row)

        section(L.t("پس‌زمینه‌ی گفتگو", "Chat background"))
        val walls = LinearLayout(this)
        for (i in 0..3) {
            val cell = FrameLayout(this).apply {
                setPadding(dp(3), dp(3), dp(3), dp(3))
                background = box(0, 14, if (i == Theme.wall(this@AppearanceActivity)) 2 else 0, pal.acc)
                addView(View(this@AppearanceActivity).apply { background = pal.wallAt(i) }, FrameLayout.LayoutParams(-1, -1))
                setOnClickListener { set("wall", i) }
            }
            walls.addView(cell, LinearLayout.LayoutParams(0, dp(96), 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        holder.addView(walls)

        section(L.t("اندازه‌ی متن", "Text size"))
        val sizes = listOf("s", "m", "l")
        chips(listOf(L.t("کوچک", "Small"), L.t("متوسط", "Medium"), L.t("بزرگ", "Large")), sizes.indexOf(Theme.size(this)).coerceAtLeast(0)) { set("size", sizes[it]) }
    }
}
