package com.example.reactapp

import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.IBinder

/** برای واجد شرایط شدن به‌عنوان پیامک پیش‌فرض لازم است؛ MMS هنوز پشتیبانی نمی‌شود */
class MmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {}
}

class RespondService : Service() {
    override fun onBind(i: Intent?): IBinder? = null
}
