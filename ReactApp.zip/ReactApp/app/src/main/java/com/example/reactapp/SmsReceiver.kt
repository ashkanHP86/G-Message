package com.example.reactapp

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Telephony
import androidx.core.app.NotificationCompat

object Notifier {
    fun show(c: Context, from: String, text: String) {
        if (ChatPrefs.has(c, "mute", Sms.key(from))) return
        if (Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val nm = c.getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("rx", L.t("پیام‌ها", "Messages"), NotificationManager.IMPORTANCE_HIGH))
        val pi = PendingIntent.getActivity(
            c, from.hashCode(), Intent(c, ChatActivity::class.java).putExtra("addr", from),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(c, "rx")
            .setSmallIcon(android.R.drawable.sym_action_chat)
            .setContentTitle(Sms.name(c, from)).setContentText(text)
            .setContentIntent(pi).setAutoCancel(true).build()
        nm.notify(from.hashCode(), n)
    }
}

/** وقتی پیش‌فرض نیستیم: فقط برای ری‌اکشن اعلان می‌دهد */
class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        L.init(c)
        if (Sms.isDefault(c)) return
        val ms = Telephony.Sms.Intents.getMessagesFromIntent(i)
        if (ms.isNullOrEmpty()) return
        val from = ms[0].originatingAddress ?: return
        val p = Rx.parse(ms.joinToString("") { it.messageBody ?: "" }) ?: return
        if (!p.add) return
        Notifier.show(c, from, "${p.custom ?: Rx.emoji(c, p.k)} " + L.t("ری‌اکشن به: ", "reacted to: ") + "“${p.quote}”")
    }
}

/** وقتی پیامک‌پیش‌فرض هستیم: پیام را ذخیره می‌کند و اعلان می‌دهد */
class SmsDeliverReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        L.init(c)
        val ms = Telephony.Sms.Intents.getMessagesFromIntent(i)
        if (ms.isNullOrEmpty()) return
        for ((from, parts) in ms.groupBy { it.originatingAddress ?: "" }) {
            if (from.isEmpty()) continue
            val body = parts.joinToString("") { it.messageBody ?: "" }
            Sms.saveIncoming(c, from, body, parts[0].timestampMillis)
            val p = Rx.parse(body)
            val text = when {
                p == null -> body
                p.add -> "${p.custom ?: Rx.emoji(c, p.k)} " + L.t("ری‌اکشن به: ", "reacted to: ") + "“${p.quote}”"
                else -> null
            }
            if (text != null) Notifier.show(c, from, text)
        }
    }
}
