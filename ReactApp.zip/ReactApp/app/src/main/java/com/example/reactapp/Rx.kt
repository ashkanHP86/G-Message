package com.example.reactapp

import android.content.Context
import java.text.BreakIterator

/** منطق ری‌اکشن: متن‌های iMessage، تنظیمات و ایموجی‌های سفارشی */
object Rx {
    // (برچسب iMessage, عبارت حذف, نام فارسی)
    val types = listOf(
        Triple("Loved", "a heart", "قلب"),
        Triple("Liked", "a like", "لایک"),
        Triple("Disliked", "a dislike", "دیس‌لایک"),
        Triple("Laughed at", "a laugh", "خنده"),
        Triple("Emphasized", "an emphasis", "تأکید"),
        Triple("Questioned", "a question mark", "سؤال")
    )
    val presets = listOf(
        listOf("❤️", "😍", "🥰", "💜", "🔥", "💖"),
        listOf("👍", "👌", "🙌", "✅", "💪", "🤝"),
        listOf("👎", "🙄", "😒", "❌", "💔", "🤨"),
        listOf("😂", "🤣", "😹", "😆", "💀", "😅"),
        listOf("‼️", "❗", "⚡", "🔔", "⭐", "🎯"),
        listOf("❓", "🤔", "🧐", "😕", "⁉️", "🙃")
    )

    private val en = listOf("Heart", "Like", "Dislike", "Laugh", "Emphasis", "Question")
    fun name(k: Int) = if (L.fa) types[k].third else en[k]

    private fun p(c: Context) = c.getSharedPreferences("rx", 0)
    fun emoji(c: Context, k: Int): String = p(c).getString("e$k", null) ?: presets[k][0]
    fun setEmoji(c: Context, k: Int, e: String) = p(c).edit().putString("e$k", e).apply()
    fun enabled(c: Context, k: Int) = p(c).getBoolean("on$k", true)
    fun setEnabled(c: Context, k: Int, on: Boolean) = p(c).edit().putBoolean("on$k", on).apply()
    fun extras(c: Context, k: Int): List<String> = (p(c).getString("x$k", "") ?: "").split(" ").filter { it.isNotBlank() }
    fun setExtras(c: Context, k: Int, l: List<String>) = p(c).edit().putString("x$k", l.joinToString(" ")).apply()
    fun reset(c: Context) = p(c).edit().clear().apply()

    /** اولین کاراکتر/ایموجی کامل از ورودی کاربر */
    fun firstChar(s: String): String? {
        val t = s.trim()
        if (t.isEmpty()) return null
        val bi = BreakIterator.getCharacterInstance()
        bi.setText(t)
        return t.substring(0, bi.next())
    }

    class P(val k: Int, val add: Boolean, val quote: String, val custom: String? = null)

    private val addRe = Regex("^(Loved|Liked|Disliked|Laughed at|Emphasized|Questioned)\\s+[“\"](.*)[”\"]$", RegexOption.DOT_MATCHES_ALL)
    private val remRe = Regex("^Removed (a heart|a like|a dislike|a laugh|an emphasis|a question mark) from\\s+[“\"](.*)[”\"]$", RegexOption.DOT_MATCHES_ALL)

    // ری‌اکشن با ایموجی دلخواه در iOS 18+: Reacted 🏳️‍🌈 to “...”
    private val reactRe = Regex("^Reacted\\s+(.+?)\\s+to\\s+[“\"](.*)[”\"]$", RegexOption.DOT_MATCHES_ALL)
    private val remAnyRe = Regex("^Removed (?:an? )?(.+?) from\\s+[“\"](.*)[”\"]$", RegexOption.DOT_MATCHES_ALL)

    fun parse(s: String): P? {
        val t = s.trim()
        addRe.find(t)?.let { m -> return P(types.indexOfFirst { it.first == m.groupValues[1] }, true, m.groupValues[2]) }
        remRe.find(t)?.let { m -> return P(types.indexOfFirst { it.second == m.groupValues[1] }, false, m.groupValues[2]) }
        reactRe.find(t)?.let { m -> return P(-1, true, m.groupValues[2], m.groupValues[1]) }
        remAnyRe.find(t)?.let { m -> return P(-1, false, m.groupValues[2], m.groupValues[1]) }
        return null
    }

    fun textAdd(k: Int, original: String) = "${types[k].first} “$original”"
    fun textRemove(k: Int, original: String) = "Removed ${types[k].second} from “$original”"

    /** ری‌اکشن با ایموجی دلخواه (غیر از ۶ نوع استاندارد) */
    fun textAddCustom(emoji: String, original: String) = "Reacted $emoji to “$original”"
    fun textRemoveCustom(emoji: String, original: String) = "Removed $emoji from “$original”"

    /** آیفون پیام‌های بلند را با … کوتاه می‌کند */
    fun matches(original: String, quoted: String): Boolean {
        val q = quoted.trim().removeSuffix("…").removeSuffix("...").trim()
        return q.isNotEmpty() && original.trim().startsWith(q)
    }
}
