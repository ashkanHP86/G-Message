package com.example.reactapp

import android.content.Context
import java.util.Locale

/** زبان رابط: auto / fa / en */
object L {
    var fa = true
    fun init(c: Context) {
        fa = when (c.getSharedPreferences("app", 0).getString("lang", "auto")) {
            "fa" -> true
            "en" -> false
            else -> Locale.getDefault().language == "fa"
        }
    }
    fun set(c: Context, v: String) { c.getSharedPreferences("app", 0).edit().putString("lang", v).apply(); init(c) }
    fun t(fa: String, en: String) = if (this.fa) fa else en
}
