package com.example.reactapp

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat

abstract class Base : AppCompatActivity() {
    lateinit var pal: Pal
    abstract fun refresh()

    private val rcv = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            Handler(Looper.getMainLooper()).postDelayed({ refresh() }, 1200)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        pal = Pal(this)
        L.init(this)
        window.decorView.layoutDirection = if (L.fa) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        window.statusBarColor = pal.bg
        window.navigationBarColor = pal.bg
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = !pal.dark
        val need = mutableListOf(Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CALL_LOG)
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        val miss = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (miss.isNotEmpty()) requestPermissions(miss.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        Sms.clearCache(); refresh()
    }

    override fun onStart() {
        super.onStart()
        ContextCompat.registerReceiver(this, rcv, IntentFilter("android.provider.Telephony.SMS_RECEIVED"), ContextCompat.RECEIVER_EXPORTED)
    }

    override fun onStop() {
        super.onStop()
        try { unregisterReceiver(rcv) } catch (_: Exception) {}
    }

    override fun onResume() { super.onResume(); refresh() }

    fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
