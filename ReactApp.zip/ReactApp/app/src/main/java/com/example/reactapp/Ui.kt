package com.example.reactapp

import android.content.Context
import android.content.res.Configuration
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.LinearLayout
import android.widget.TextView

class Pal(c: Context) {
    val dark = (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    private fun p(l: Long, d: Long) = (if (dark) d else l).toInt()
    val bg = p(0xFFFFFFFF, 0xFF13161D)
    val soft = p(0xFFF2F4F9, 0xFF1C202A)
    val inb = p(0xFFF0F2F8, 0xFF222733)
    val ink = p(0xFF12151C, 0xFFF1F3F8)
    val mut = p(0xFF7A8294, 0xFF8B93A5)
    val acc = p(0xFF5B4BFF, 0xFF7A6DFF)
    val acc2 = p(0xFF8A4DFF, 0xFFA06BFF)
}

const val WHITE = -1

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

fun Context.box(color: Int, r: Int, stroke: Int = 0, strokeColor: Int = 0) = GradientDrawable().apply {
    setColor(color); cornerRadius = dp(r).toFloat(); if (stroke > 0) setStroke(dp(stroke), strokeColor)
}

fun Context.grad(a: Int, b: Int, r: Int) =
    GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(a, b)).apply { cornerRadius = dp(r).toFloat() }

fun Context.tv(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
    text = t; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
}

fun Context.circle(t: String, bg: Drawable, size: Int, ts: Float, color: Int, click: (() -> Unit)? = null) = TextView(this).apply {
    text = t; textSize = ts; setTextColor(color); gravity = Gravity.CENTER; background = bg
    layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
    if (click != null) setOnClickListener { click() }
}

class Ad<T>(var items: List<T>, private val build: (T) -> View) : BaseAdapter() {
    override fun getCount() = items.size
    override fun getItem(p: Int) = items[p]
    override fun getItemId(p: Int) = p.toLong()
    override fun getView(p: Int, v: View?, g: ViewGroup?) = build(items[p])
}
