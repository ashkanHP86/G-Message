package com.example.reactapp

import android.content.Context
import android.content.res.Configuration
import android.graphics.drawable.ColorDrawable
import androidx.core.graphics.ColorUtils
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class Pal(private val c: Context) {
    private val mode = Theme.mode(c)
    val dark = when (mode) {
        "light" -> false
        "dark", "black" -> true
        else -> (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }
    private val black = mode == "black"
    private val ai = Theme.accent(c).coerceIn(0, Theme.accents.size - 1)
    private fun pick(l: Long, d: Long, b: Long) = (if (black) b else if (dark) d else l).toInt()
    // رنگ‌ها از سورس تلگرام (ThemeColors.java، تم روز) گرفته شده است
    val acc = Theme.accents[ai]
    val acc2 = acc
    val bg = pick(0xFFFFFFFF, 0xFF17212B, 0xFF000000)
    val bar = pick(0xFFFFFFFF, 0xFF242F3D, 0xFF000000)
    val soft = pick(0xFFF1F1F3, 0xFF242F3D, 0xFF141414)
    val inb = pick(0xFFFFFFFF, 0xFF182533, 0xFF1E1E1E)
    val outb = if (ai == 0) pick(0xFFEFFFDE, 0xFF2B5278, 0xFF2B5278)
        else ColorUtils.blendARGB(acc, if (dark) 0xFF000000.toInt() else 0xFFFFFFFF.toInt(), if (dark) 0.5f else 0.85f)
    val ink = pick(0xFF1A1D21, 0xFFF1F3F8, 0xFFF1F3F8)
    val mut = pick(0xFF75787A, 0xFF6D7F8F, 0xFF6D7F8F)
    val line = pick(0xFFD9D9D9, 0xFF0E1621, 0xFF1E1E1E)
    val tick = pick(0xFF5DB050, 0xFF7DA8D3, 0xFF7DA8D3)
    val inTime = pick(0xFFA1AAB3, 0xFF6D7F8F, 0xFF6D7F8F)
    val outTime = pick(0xFF70B15C, 0xFF7DA8D3, 0xFF7DA8D3)
    val fab = if (ai == 0 && !dark) 0xFF65A9E0.toInt() else acc

    fun wallAt(i: Int): Drawable {
        val g = { a: Long, b: Long -> GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(a.toInt(), b.toInt())) }
        return when (i) {
            1 -> if (dark) g(0xFF0F1A2A, 0xFF16263D) else g(0xFFD7E4B5, 0xFF8FC49E)
            2 -> if (dark) g(0xFF0F2318, 0xFF1A3A26) else g(0xFFDDEFD5, 0xFFBFE0B2)
            3 -> if (dark) g(0xFF2B1B4A, 0xFF14223F) else g(0xFFF3E1F5, 0xFFD6E4FA)
            else -> ColorDrawable(bg)
        }
    }
    fun wall() = wallAt(Theme.wall(c))
}

const val WHITE = -1

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

fun Context.box(color: Int, r: Int, stroke: Int = 0, strokeColor: Int = 0) = GradientDrawable().apply {
    setColor(color); cornerRadius = dp(r).toFloat(); if (stroke > 0) setStroke(dp(stroke), strokeColor)
}

fun Context.grad(a: Int, b: Int, r: Int) =
    GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(a, b)).apply { cornerRadius = dp(r).toFloat() }

fun Context.tv(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
    text = t; textSize = size * Theme.scale; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
}

fun Context.circle(t: String, bg: Drawable, size: Int, ts: Float, color: Int, click: (() -> Unit)? = null) = TextView(this).apply {
    text = t; textSize = ts; setTextColor(color); gravity = Gravity.CENTER; background = bg
    layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
    if (click != null) setOnClickListener { click() }
}

class Ad<T>(var items: List<T>, private val build: (T) -> View) : BaseAdapter() {
    override fun getCount() = items.size
    override fun getItem(p: Int) = items[p]
    override fun getItemId(p: Int) = p.toLong()
    override fun getView(p: Int, v: View?, g: ViewGroup?) = build(items[p])
}

fun Context.icon(res: Int, tint: Int, click: (() -> Unit)? = null) = ImageView(this).apply {
    setImageResource(res); setColorFilter(tint); scaleType = ImageView.ScaleType.CENTER
    layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
    if (click != null) setOnClickListener { click() }
}

private val AVC = intArrayOf(0xFFFF845E.toInt(), 0xFFFEBB5B.toInt(), 0xFFB694F9.toInt(), 0xFF9AD164.toInt(), 0xFF5BCBE3.toInt(), 0xFF5CAFFA.toInt(), 0xFFFF8AAC.toInt())

/** آواتار با رنگ‌های تلگرام */
fun Context.tgAvatar(name: String, size: Int, ts: Float): TextView {
    val c = AVC[Math.abs(name.hashCode()) % AVC.size]
    val bg = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(c, ColorUtils.blendARGB(c, 0xFF000000.toInt(), 0.18f))).apply { shape = GradientDrawable.OVAL }
    return circle(name.firstOrNull { it.isLetter() }?.uppercase() ?: "#", bg, size, ts, WHITE).apply { setTypeface(typeface, Typeface.BOLD) }
}

/** حباب پیام با دم گوشه‌ی پایین (راست برای ارسالی، چپ برای دریافتی) */
fun Context.bubbleBg(color: Int, tailRight: Boolean): GradientDrawable {
    val r = dp(17).toFloat(); val s = dp(4).toFloat()
    return GradientDrawable().apply {
        setColor(color)
        cornerRadii = if (tailRight) floatArrayOf(r, r, r, r, s, s, r, r) else floatArrayOf(r, r, r, r, r, r, s, s)
    }
}
