package com.example.reactapp

import android.app.Activity
import android.app.role.RoleManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.telephony.SmsManager
import org.json.JSONArray
import org.json.JSONObject

data class Rc(val k: Int, val me: Boolean, val e: String? = null)
data class Msg(val body: String, val date: Long, val mine: Boolean, val rx: MutableList<Rc> = mutableListOf())
data class Conv(val addr: String, val name: String, val last: String, val date: Long, val mine: Boolean, val unread: Int = 0)
private data class Row(val addr: String, val body: String, val date: Long, val mine: Boolean, val read: Boolean = true)

object Sms {
    private val names = HashMap<String, String>()
    fun clearCache() = names.clear()
    fun key(a: String) = a.filter { it.isDigit() }.takeLast(9)

    private fun rows(c: Context): List<Row> {
        val out = mutableListOf<Row>()
        try {
            c.contentResolver.query(
                Uri.parse("content://sms"), arrayOf("address", "body", "date", "type", "read"),
                null, null, "date DESC LIMIT 3000"
            )?.use { q ->
                while (q.moveToNext()) {
                    val t = q.getInt(3)
                    if (t == 1 || t == 2) out.add(Row(q.getString(0) ?: continue, q.getString(1) ?: "", q.getLong(2), t == 2, q.getInt(4) == 1))
                }
            }
        } catch (_: SecurityException) {
        }
        // اندروید پیامک‌های ارسالیِ اپ‌های غیرپیش‌فرض را ثبت نمی‌کند؛ پس خودمان نگه می‌داریم
        for (o in outbox(c)) {
            val dup = out.any { it.mine && key(it.addr) == key(o.addr) && it.body == o.body && Math.abs(it.date - o.date) < 120000 }
            if (!dup) out.add(o)
        }
        return out.sortedBy { it.date }
    }

    private fun outbox(c: Context): List<Row> {
        val a = JSONArray(c.getSharedPreferences("out", 0).getString("l", "[]"))
        return (0 until a.length()).map { val o = a.getJSONObject(it); Row(o.getString("a"), o.getString("b"), o.getLong("d"), true) }
    }

    private fun addOut(c: Context, to: String, body: String) {
        val a = JSONArray()
        (outbox(c).takeLast(999) + Row(to, body, System.currentTimeMillis(), true))
            .forEach { a.put(JSONObject().put("a", it.addr).put("b", it.body).put("d", it.date)) }
        c.getSharedPreferences("out", 0).edit().putString("l", a.toString()).apply()
    }

    fun name(c: Context, addr: String): String = names.getOrPut(addr) {
        try {
            c.contentResolver.query(
                Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(addr)),
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null
            )?.use { if (it.moveToFirst()) it.getString(0) else null } ?: addr
        } catch (_: Exception) {
            addr
        }
    }

    fun conversations(c: Context): List<Conv> =
        rows(c).groupBy { key(it.addr) }.filterKeys { it.isNotEmpty() }.values.map { g ->
            val l = g.last()
            val p = Rx.parse(l.body)
            Conv(l.addr, name(c, l.addr), if (p != null) (p.custom ?: Rx.emoji(c, p.k)) + " " + p.quote else l.body, l.date, l.mine, g.count { !it.mine && !it.read })
        }.sortedByDescending { it.date }

    fun thread(c: Context, addr: String): List<Msg> {
        val res = mutableListOf<Msg>()
        for (r in rows(c).filter { key(it.addr) == key(addr) }) {
            val p = Rx.parse(r.body)
            val t = if (p != null) res.lastOrNull { Rx.matches(it.body, p.quote) } else null
            if (p != null && t != null) {
                t.rx.removeAll { it.k == p.k && it.e == p.custom && it.me == r.mine }
                if (p.add) t.rx.add(Rc(p.k, r.mine, p.custom))
            } else res.add(Msg(r.body, r.date, r.mine))
        }
        return res.takeLast(500)
    }

    fun markRead(c: Context, addr: String) {
        if (!isDefault(c)) return
        val v = ContentValues().apply { put("read", 1); put("seen", 1) }
        try { c.contentResolver.update(Uri.parse("content://sms/inbox"), v, "address LIKE ? AND read=0", arrayOf("%" + key(addr))) } catch (_: Exception) {}
    }

    fun deleteThread(c: Context, addr: String) {
        try { c.contentResolver.delete(Uri.parse("content://sms"), "address LIKE ?", arrayOf("%" + key(addr))) } catch (_: Exception) {}
    }

    fun deleteMessage(c: Context, m: Msg) {
        try { c.contentResolver.delete(Uri.parse("content://sms"), "date=? AND body=?", arrayOf(m.date.toString(), m.body)) } catch (_: Exception) {}
    }

    fun isDefault(c: Context) = Telephony.Sms.getDefaultSmsPackage(c) == c.packageName

    /** درخواست پیامک پیش‌فرض شدن */
    fun askDefault(a: Activity) {
        val i = if (Build.VERSION.SDK_INT >= 29) a.getSystemService(RoleManager::class.java).createRequestRoleIntent(RoleManager.ROLE_SMS)
        else Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT).putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, a.packageName)
        a.startActivity(i)
    }

    /** فقط اپ پیش‌فرض باید پیامک ورودی را در حافظه‌ی سیستم بنویسد */
    fun saveIncoming(c: Context, from: String, body: String, ts: Long) {
        val v = ContentValues().apply { put("address", from); put("body", body); put("date", ts); put("read", 0); put("seen", 0) }
        try { c.contentResolver.insert(Telephony.Sms.Inbox.CONTENT_URI, v) } catch (_: Exception) {}
    }

    private fun saveSent(c: Context, to: String, body: String) {
        val v = ContentValues().apply { put("address", to); put("body", body); put("date", System.currentTimeMillis()); put("read", 1) }
        try { c.contentResolver.insert(Telephony.Sms.Sent.CONTENT_URI, v) } catch (_: Exception) { addOut(c, to, body) }
    }

    fun send(c: Context, to: String, text: String): Boolean = try {
        val sm = if (Build.VERSION.SDK_INT >= 31) c.getSystemService(SmsManager::class.java)
        else @Suppress("DEPRECATION") SmsManager.getDefault()
        sm.sendMultipartTextMessage(to, null, sm.divideMessage(text), null, null)
        if (isDefault(c)) saveSent(c, to, text) else addOut(c, to, text)
        true
    } catch (e: Exception) {
        false
    }
}
