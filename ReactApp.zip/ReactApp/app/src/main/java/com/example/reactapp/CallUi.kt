package com.example.reactapp

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import android.telecom.VideoProfile
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat

object Tel {
    var current: Call? = null
    var svc: InCallService? = null
    var listener: (() -> Unit)? = null
    val cb = object : Call.Callback() {
        override fun onStateChanged(call: Call?, state: Int) {
            if (state != Call.STATE_RINGING) svc?.getSystemService(NotificationManager::class.java)?.cancel(77)
            listener?.invoke()
        }
    }
}

/** سرویسی که سیستم برای تماس‌ها صدا می‌زند (فقط وقتی اپ «برنامه‌ی تماس پیش‌فرض» باشد) */
class CallService : InCallService() {
    override fun onCreate() { super.onCreate(); Tel.svc = this }
    override fun onDestroy() { Tel.svc = null; super.onDestroy() }

    override fun onCallAdded(call: Call) {
        Tel.current = call
        call.registerCallback(Tel.cb)
        val i = Intent(this, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (call.state == Call.STATE_RINGING) ring(call, i) else startActivity(i)
    }

    override fun onCallRemoved(call: Call) {
        call.unregisterCallback(Tel.cb)
        if (Tel.current == call) Tel.current = null
        getSystemService(NotificationManager::class.java).cancel(77)
        Tel.listener?.invoke()
    }

    override fun onCallAudioStateChanged(s: CallAudioState?) { Tel.listener?.invoke() }

    private fun ring(call: Call, i: Intent) {
        L.init(this)
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("call", L.t("تماس ورودی", "Incoming call"), NotificationManager.IMPORTANCE_HIGH).apply { setSound(null, null) })
        val pi = PendingIntent.getActivity(this, 1, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val num = call.details?.handle?.schemeSpecificPart ?: ""
        nm.notify(77, NotificationCompat.Builder(this, "call").setSmallIcon(android.R.drawable.sym_action_call)
            .setContentTitle(if (num.isEmpty()) L.t("ناشناس", "Unknown") else Sms.name(this, num)).setContentText(L.t("تماس ورودی", "Incoming call"))
            .setCategory(NotificationCompat.CATEGORY_CALL).setPriority(NotificationCompat.PRIORITY_HIGH)
            .setOngoing(true).setFullScreenIntent(pi, true).setContentIntent(pi).build())
        try { startActivity(i) } catch (_: Exception) {}
    }
}

class InCallActivity : AppCompatActivity() {
    private lateinit var pal: Pal
    private lateinit var av: TextView
    private lateinit var nameV: TextView
    private lateinit var stateV: TextView
    private lateinit var btns: LinearLayout
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable { override fun run() { render(); h.postDelayed(this, 1000) } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        pal = Pal(this)
        L.init(this)
        window.decorView.layoutDirection = if (L.fa) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(pal.bg); setPadding(dp(24), dp(90), dp(24), dp(56))
        }
        av = circle("؟", grad(pal.acc, pal.acc2, 55), 110, 40f, WHITE)
        nameV = tv("", 30f, pal.ink, true)
        stateV = tv("", 16f, pal.mut)
        root.addView(av)
        root.addView(nameV, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(20) })
        root.addView(stateV, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(6) })
        root.addView(View(this), LinearLayout.LayoutParams(0, 0, 1f))
        btns = LinearLayout(this).apply { gravity = Gravity.CENTER }
        root.addView(btns, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    override fun onStart() { super.onStart(); Tel.listener = { render() }; h.post(tick) }
    override fun onStop() { super.onStop(); Tel.listener = null; h.removeCallbacks(tick) }

    private fun render() {
        val call = Tel.current ?: run { finish(); return }
        val num = call.details?.handle?.schemeSpecificPart ?: ""
        val nm = if (num.isEmpty()) L.t("ناشناس", "Unknown") else Sms.name(this, num)
        nameV.text = nm
        av.text = nm.firstOrNull { it.isLetter() }?.uppercase() ?: "#"
        val st = call.state
        stateV.text = when (st) {
            Call.STATE_RINGING -> L.t("تماس ورودی", "Incoming call")
            Call.STATE_DIALING, Call.STATE_CONNECTING -> L.t("در حال تماس…", "Calling…")
            Call.STATE_HOLDING -> L.t("در انتظار", "On hold")
            Call.STATE_ACTIVE -> { val s = ((System.currentTimeMillis() - call.details.connectTimeMillis) / 1000).coerceAtLeast(0); "%02d:%02d".format(s / 60, s % 60) }
            else -> L.t("پایان تماس", "Call ended")
        }
        btns.removeAllViews()
        val lp = { LinearLayout.LayoutParams(dp(76), dp(76)).apply { setMargins(dp(14), 0, dp(14), 0) } }
        val red = 0xFFE53935.toInt()
        if (st == Call.STATE_RINGING) {
            btns.addView(circle("✕", box(red, 38), 76, 26f, WHITE) { call.reject(false, null) }, lp())
            btns.addView(circle("✆", box(0xFF2EAD4F.toInt(), 38), 76, 26f, WHITE) { call.answer(VideoProfile.STATE_AUDIO_ONLY) }, lp())
        } else {
            val svc = Tel.svc
            val muted = svc?.callAudioState?.isMuted == true
            val spk = svc?.callAudioState?.route == CallAudioState.ROUTE_SPEAKER
            btns.addView(circle("🎤", box(if (muted) pal.acc else pal.soft, 38), 76, 24f, pal.ink) { svc?.setMuted(!muted) }, lp())
            btns.addView(circle("✆", box(red, 38), 76, 26f, WHITE) { call.disconnect() }, lp())
            btns.addView(circle("🔊", box(if (spk) pal.acc else pal.soft, 38), 76, 24f, pal.ink) {
                svc?.setAudioRoute(if (spk) CallAudioState.ROUTE_EARPIECE else CallAudioState.ROUTE_SPEAKER)
            }, lp())
        }
    }
}
