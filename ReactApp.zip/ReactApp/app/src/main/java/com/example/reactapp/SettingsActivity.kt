package com.example.reactapp

import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.SwitchCompat

class SettingsActivity : Base() {
    private lateinit var holder: LinearLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val sv = ScrollView(this).apply { setBackgroundColor(pal.bg) }
        holder = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(20), dp(16), dp(24)) }
        sv.addView(holder)
        setContentView(sv)
    }

    override fun refresh() = build()

    private fun build() {
        holder.removeAllViews()
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(circle(if (L.fa) "›" else "‹", box(pal.soft, 21), 42, 22f, pal.ink) { finish() })
        head.addView(tv(L.t("ری‌اکشن‌ها", "Reactions"), 24f, pal.ink, true), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12) })
        holder.addView(head)
        holder.addView(
            tv(L.t("برای هر ری‌اکشن یک استیکر دلخواه انتخاب کن یا ایموجی جدید اضافه کن. استیکر فقط در همین اپ دیده می‌شود و متن ارسالی برای آیفون ثابت است.", "Pick a custom sticker for each reaction or add a new emoji. Stickers only show in this app; the text sent to iPhone never changes."), 13f, pal.mut)
                .apply { setPadding(0, dp(12), 0, dp(12)); setLineSpacing(0f, 1.3f) }
        )
        for (k in Rx.types.indices) holder.addView(item(k))
        holder.addView(
            tv(L.t("بازگشت به پیش‌فرض", "Reset to default"), 15f, pal.ink, true).apply {
                gravity = Gravity.CENTER; background = box(pal.soft, 16); setPadding(0, dp(14), 0, dp(14))
                setOnClickListener { Rx.reset(this@SettingsActivity); build() }
            },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) }
        )
    }

    private fun item(k: Int): View {
        val t = Rx.types[k]
        val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(10), dp(4), dp(10)) }
        r.addView(circle(Rx.emoji(this, k), box(pal.soft, 16), 52, 26f, pal.ink) { pick(k) })
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, dp(14), 0) }
        c.addView(tv(Rx.name(k), 16f, pal.ink, true))
        c.addView(tv("${t.first} “…”", 12f, pal.mut).apply { textDirection = View.TEXT_DIRECTION_LTR })
        r.addView(c, LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(SwitchCompat(this).apply {
            isChecked = Rx.enabled(this@SettingsActivity, k)
            setOnCheckedChangeListener { v, on ->
                if (!on && Rx.types.indices.count { Rx.enabled(this@SettingsActivity, it) } == 1) {
                    v.isChecked = true; toast(L.t("حداقل یک ری‌اکشن باید روشن بماند", "At least one reaction must stay on"))
                } else Rx.setEnabled(this@SettingsActivity, k, on)
            }
        })
        return r
    }

    /** انتخاب استیکر از پیش‌فرض‌ها یا ایموجی‌های اضافه‌شده؛ نگه‌داشتن روی ایموجی اضافه‌شده = حذف */
    private fun pick(k: Int) {
        val ex = Rx.extras(this, k)
        val all = (Rx.presets[k] + ex).distinct()
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), 0) }
        val grid = GridLayout(this).apply { columnCount = 6 }
        lateinit var dlg: AlertDialog
        for (e in all) grid.addView(
            circle(e, box(if (e == Rx.emoji(this, k)) pal.soft else 0, 14), 44, 24f, pal.ink) {
                Rx.setEmoji(this, k, e); dlg.dismiss(); build()
            }.apply {
                if (e in ex) setOnLongClickListener {
                    Rx.setExtras(this@SettingsActivity, k, ex - e); dlg.dismiss(); build(); true
                }
            }
        )
        val et = EditText(this).apply { hint = L.t("ایموجی جدید", "New emoji"); textSize = 18f }
        val add = tv(L.t("افزودن", "Add"), 15f, pal.acc, true).apply { setPadding(dp(12), dp(10), dp(12), dp(10)) }
        val line = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        line.addView(et, LinearLayout.LayoutParams(0, -2, 1f))
        line.addView(add)
        add.setOnClickListener {
            val e = Rx.firstChar(et.text.toString()) ?: return@setOnClickListener
            if (e !in all) Rx.setExtras(this, k, ex + e)
            Rx.setEmoji(this, k, e); dlg.dismiss(); build()
        }
        wrap.addView(grid)
        wrap.addView(line, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        dlg = AlertDialog.Builder(this).setTitle(L.t("استیکر ${Rx.name(k)}", "Sticker: ${Rx.name(k)}")).setView(wrap).setNegativeButton(L.t("بستن", "Close"), null).create()
        dlg.show()
    }
}
