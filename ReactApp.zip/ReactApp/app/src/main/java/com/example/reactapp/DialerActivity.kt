package com.example.reactapp

import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView

class DialerActivity : Base() {
    private lateinit var num: TextView
    private val sb = StringBuilder()

    override fun refresh() {}

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        intent.data?.schemeSpecificPart?.let { sb.append(it) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(pal.bg); setPadding(dp(24), dp(24), dp(24), dp(24))
        }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(circle(if (L.fa) "›" else "‹", box(pal.soft, 21), 42, 22f, pal.ink) { finish() })
        head.addView(tv(L.t("صفحه‌کلید", "Keypad"), 20f, pal.ink, true), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12) })
        num = tv(sb.toString(), 32f, pal.ink, true).apply { gravity = Gravity.CENTER; textDirection = View.TEXT_DIRECTION_LTR }

        val grid = GridLayout(this).apply { columnCount = 3 }
        val keys = listOf("1" to "", "2" to "ABC", "3" to "DEF", "4" to "GHI", "5" to "JKL", "6" to "MNO",
            "7" to "PQRS", "8" to "TUV", "9" to "WXYZ", "*" to "", "0" to "+", "#" to "")
        for ((d, l) in keys) grid.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; background = box(pal.soft, 42)
            addView(tv(d, 26f, pal.ink, true).apply { gravity = Gravity.CENTER })
            addView(tv(l, 10f, pal.mut).apply { gravity = Gravity.CENTER })
            layoutParams = GridLayout.LayoutParams().apply { width = dp(84); height = dp(84); setMargins(dp(10), dp(8), dp(10), dp(8)) }
            setOnClickListener { sb.append(d); show() }
        })

        val bottom = LinearLayout(this).apply { gravity = Gravity.CENTER }
        bottom.addView(View(this), LinearLayout.LayoutParams(dp(56), dp(56)))
        bottom.addView(circle("✆", box(0xFF2EAD4F.toInt(), 36), 72, 28f, WHITE) { Phone.call(this, sb.toString()) },
            LinearLayout.LayoutParams(dp(72), dp(72)).apply { setMargins(dp(24), 0, dp(24), 0) })
        bottom.addView(circle("⌫", box(pal.soft, 28), 56, 20f, pal.ink) { if (sb.isNotEmpty()) { sb.setLength(sb.length - 1); show() } }
            .apply { setOnLongClickListener { sb.setLength(0); show(); true } })

        root.addView(head, LinearLayout.LayoutParams(-1, -2))
        root.addView(num, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(grid)
        root.addView(bottom, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        setContentView(root)
    }

    private fun show() { num.text = sb.toString() }
}
