package com.example.reactapp

import android.app.Activity
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Phone as PhoneCol
import android.telecom.TelecomManager

data class Contact(val name: String, val number: String)
data class CallRow(val name: String, val number: String, val date: Long, val type: Int, val dur: Long)

object Phone {
    fun contacts(c: Context): List<Contact> {
        val out = LinkedHashMap<String, Contact>()
        try {
            c.contentResolver.query(PhoneCol.CONTENT_URI, arrayOf(PhoneCol.DISPLAY_NAME, PhoneCol.NUMBER), null, null, PhoneCol.DISPLAY_NAME + " COLLATE LOCALIZED ASC")?.use { q ->
                while (q.moveToNext()) {
                    val n = q.getString(0) ?: continue
                    val p = q.getString(1) ?: continue
                    out.putIfAbsent(n + Sms.key(p), Contact(n, p))
                }
            }
        } catch (_: SecurityException) {}
        return out.values.toList()
    }

    fun callLog(c: Context): List<CallRow> {
        val out = mutableListOf<CallRow>()
        try {
            c.contentResolver.query(CallLog.Calls.CONTENT_URI, arrayOf("number", "type", "date", "duration", "name"), null, null, "date DESC LIMIT 200")?.use { q ->
                while (q.moveToNext()) {
                    val num = q.getString(0) ?: ""
                    out.add(CallRow(q.getString(4)?.takeIf { it.isNotBlank() } ?: num.ifEmpty { L.t("ناشناس", "Unknown") }, num, q.getLong(2), q.getInt(1), q.getLong(3)))
                }
            }
        } catch (_: SecurityException) {}
        return out
    }

    fun call(a: Activity, number: String) {
        if (number.isBlank()) return
        val uri = Uri.fromParts("tel", number, null)
        try { a.getSystemService(TelecomManager::class.java).placeCall(uri, Bundle()) }
        catch (e: SecurityException) { a.startActivity(Intent(Intent.ACTION_DIAL, uri)) }
    }

    fun isDialer(c: Context) = c.getSystemService(TelecomManager::class.java).defaultDialerPackage == c.packageName

    fun askDialer(a: Activity) {
        val i = if (Build.VERSION.SDK_INT >= 29) a.getSystemService(RoleManager::class.java).createRequestRoleIntent(RoleManager.ROLE_DIALER)
        else Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER).putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, a.packageName)
        a.startActivity(i)
    }
}
