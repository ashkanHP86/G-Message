package com.example.reactapp

import android.content.Intent
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.text.TextUtils
import android.text.format.DateUtils
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.core.widget.doAfterTextChanged
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Base() {
    private lateinit var title: TextView
    private lateinit var searchBox: EditText
    private lateinit var tabsRow: View
    private lateinit var fab: ImageView
    private lateinit var scrim: View
    private lateinit var panel: LinearLayout
    private lateinit var banner: TextView
    private lateinit var dialBanner: TextView
    private lateinit var ad: Ad<Conv>
    private lateinit var cad: Ad<Contact>
    private lateinit var lad: Ad<CallRow>
    private val pages = mutableListOf<View>()
    private val tabText = mutableListOf<TextView>()
    private val tabInd = mutableListOf<View>()
    private var tab = 0
    private var filter = 0
    private var all = listOf<Conv>()
    private val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val fmtD = SimpleDateFormat("MMM d", Locale.getDefault())

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = FrameLayout(this).apply { setBackgroundColor(pal.bg) }
        val main = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(pal.bar); setPadding(dp(4), 0, dp(4), 0); elevation = dp(2).toFloat() }
        bar.addView(icon(R.drawable.ic_menu, pal.ink) { openDrawer() })
        title = tv("G Message", 20f, pal.ink, true).apply { gravity = Gravity.CENTER_VERTICAL }
        bar.addView(title, LinearLayout.LayoutParams(0, dp(56), 1f).apply { marginStart = dp(12) })
        searchBox = EditText(this).apply {
            hint = L.t("جستجو…", "Search…"); textSize = 18f; setTextColor(pal.ink); setHintTextColor(pal.mut)
            background = null; setSingleLine(); visibility = View.GONE; doAfterTextChanged { render() }
        }
        bar.addView(searchBox, LinearLayout.LayoutParams(0, dp(56), 1f))
        bar.addView(icon(R.drawable.ic_search, pal.ink) { toggleSearch() })
        main.addView(bar)

        val tr = LinearLayout(this).apply { setBackgroundColor(pal.bar) }
        listOf(L.t("همه", "All"), L.t("نخوانده", "Unread"), L.t("آرشیو", "Archived")).forEachIndexed { i, t ->
            val tx = tv(t, 14f, pal.mut, true).apply { setPadding(dp(16), dp(12), dp(16), dp(10)) }
            val ind = View(this)
            tabText.add(tx); tabInd.add(ind)
            tr.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                addView(tx); addView(ind, LinearLayout.LayoutParams(-1, dp(3)))
                setOnClickListener { filter = i; styleTabs(); render() }
            })
        }
        tabsRow = tr
        styleTabs()
        main.addView(tr)

        val content = FrameLayout(this)
        pages.add(chatsPage()); pages.add(contactsPage()); pages.add(callsPage())
        pages.forEach { content.addView(it) }
        main.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(main)

        fab = ImageView(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(pal.fab) }
            scaleType = ImageView.ScaleType.CENTER; setColorFilter(WHITE); elevation = dp(6).toFloat()
            setOnClickListener { if (tab == 0) newChat() else startActivity(Intent(this@MainActivity, DialerActivity::class.java)) }
        }
        root.addView(fab, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.BOTTOM or Gravity.END).apply { setMargins(dp(16), 0, dp(16), dp(16)) })

        scrim = View(this).apply { setBackgroundColor(0x66000000); visibility = View.GONE; setOnClickListener { closeDrawer() } }
        root.addView(scrim, FrameLayout.LayoutParams(-1, -1))
        panel = buildDrawer()
        root.addView(panel, FrameLayout.LayoutParams(dp(290), -1, Gravity.START))
        setContentView(root)
        select(0)
    }

    override fun onBackPressed() {
        when {
            panel.visibility == View.VISIBLE -> closeDrawer()
            tab != 0 -> select(0)
            else -> super.onBackPressed()
        }
    }

    // ---------- ناوبری ----------
    private fun select(i: Int) {
        tab = i
        pages.forEachIndexed { k, v -> v.visibility = if (k == i) View.VISIBLE else View.GONE }
        tabsRow.visibility = if (i == 0) View.VISIBLE else View.GONE
        title.text = when (i) { 0 -> "G Message"; 1 -> L.t("مخاطبین", "Contacts"); else -> L.t("تماس‌ها", "Calls") }
        fab.visibility = if (i == 1) View.GONE else View.VISIBLE
        fab.setImageResource(if (i == 2) R.drawable.ic_dialpad else R.drawable.ic_pencil)
        refresh()
    }

    override fun refresh() {
        if (!::panel.isInitialized) return
        banner.visibility = if (Sms.isDefault(this)) View.GONE else View.VISIBLE
        dialBanner.visibility = if (Phone.isDialer(this)) View.GONE else View.VISIBLE
        when (tab) {
            0 -> { all = Sms.conversations(this); render() }
            1 -> { cad.items = Phone.contacts(this); cad.notifyDataSetChanged() }
            2 -> { lad.items = Phone.callLog(this); lad.notifyDataSetChanged() }
        }
    }

    private fun toggleSearch() {
        val on = searchBox.visibility != View.VISIBLE
        searchBox.visibility = if (on) View.VISIBLE else View.GONE
        title.visibility = if (on) View.GONE else View.VISIBLE
        val imm = getSystemService(InputMethodManager::class.java)
        if (on) { searchBox.requestFocus(); imm.showSoftInput(searchBox, 0) }
        else { searchBox.setText(""); imm.hideSoftInputFromWindow(searchBox.windowToken, 0) }
    }

    private fun off() = (if (L.fa) 1 else -1) * dp(290).toFloat()
    private fun openDrawer() {
        scrim.visibility = View.VISIBLE; panel.visibility = View.VISIBLE
        panel.translationX = off(); panel.animate().translationX(0f).setDuration(200).start()
    }
    private fun closeDrawer() {
        panel.animate().translationX(off()).setDuration(180).withEndAction { panel.visibility = View.GONE; scrim.visibility = View.GONE }.start()
    }

    private fun buildDrawer(): LinearLayout {
        val p = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(pal.bg); visibility = View.GONE; elevation = dp(16).toFloat(); isClickable = true }
        val head = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(pal.acc); setPadding(dp(16), dp(40), dp(16), dp(16)) }
        head.addView(tgAvatar("G", 64, 26f))
        head.addView(tv("G Message", 18f, WHITE, true), LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(12) })
        head.addView(tv(L.t("پیامک و تماس", "SMS & Calls"), 13f, 0xCCFFFFFF.toInt()))
        p.addView(head)
        fun item(ic: Int, t: String, go: () -> Unit) = p.addView(LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(2), dp(16), dp(2))
            addView(ImageView(this@MainActivity).apply { setImageResource(ic); setColorFilter(pal.mut); layoutParams = LinearLayout.LayoutParams(dp(24), dp(48)) })
            addView(tv(t, 15f, pal.ink, true), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(24) })
            setOnClickListener { closeDrawer(); go() }
        })
        item(R.drawable.ic_pencil, L.t("پیام جدید", "New message")) { newChat() }
        item(R.drawable.ic_person, L.t("مخاطبین", "Contacts")) { select(1) }
        item(R.drawable.ic_call, L.t("تماس‌ها", "Calls")) { select(2) }
        p.addView(View(this).apply { setBackgroundColor(pal.line) }, LinearLayout.LayoutParams(-1, 1).apply { setMargins(0, dp(6), 0, dp(6)) })
        item(R.drawable.ic_settings, L.t("ظاهر", "Appearance")) { startActivity(Intent(this, AppearanceActivity::class.java)) }
        item(R.drawable.ic_emoji, L.t("تنظیمات ری‌اکشن", "Reaction settings")) { startActivity(Intent(this, SettingsActivity::class.java)) }
        item(R.drawable.ic_settings, L.t("پیامک پیش‌فرض", "Default SMS app")) { Sms.askDefault(this) }
        item(R.drawable.ic_call, L.t("برنامه‌ی تماس پیش‌فرض", "Default phone app")) { Phone.askDialer(this) }
        item(R.drawable.ic_lang, L.t("زبان", "Language")) { langDialog() }
        return p
    }

    // ---------- صفحه‌ها ----------
    private fun listV() = ListView(this).apply { divider = null; selector = ColorDrawable(0); clipToPadding = false; setPadding(0, 0, 0, dp(88)) }

    private fun bannerV(text: String, click: () -> Unit) = tv(text, 13f, WHITE, true).apply {
        setBackgroundColor(pal.acc); setPadding(dp(16), dp(10), dp(16), dp(10)); setOnClickListener { click() }
    }

    private fun chatsPage(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        banner = bannerV(L.t("برای دریافت و ذخیره‌ی کامل پیامک‌ها، این اپ را پیامک پیش‌فرض کن  ›", "Make this app your default SMS app  ›")) { Sms.askDefault(this) }
        col.addView(banner)
        val list = listV(); ad = Ad(listOf()) { c -> row(c) }; list.adapter = ad
        col.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        return col
    }

    private fun contactsPage(): View {
        val list = listV()
        cad = Ad(listOf()) { c -> item(c.name, c.number, pal.mut, R.drawable.ic_call, { open(c.number) }) { Phone.call(this, c.number) } }
        list.adapter = cad
        return list
    }

    private fun callsPage(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        dialBanner = bannerV(L.t("برای نمایش صفحه‌ی تماس در این اپ، آن را برنامه‌ی تماس پیش‌فرض کن  ›", "Make this app your default phone app  ›")) { Phone.askDialer(this) }
        col.addView(dialBanner)
        val list = listV()
        lad = Ad(listOf()) { c ->
            val (lbl, red) = when (c.type) { 1 -> L.t("↙ ورودی", "↙ Incoming") to false; 2 -> L.t("↗ خروجی", "↗ Outgoing") to false; else -> L.t("✕ بی‌پاسخ", "✕ Missed") to true }
            item(c.name, "$lbl • ${time(c.date)}", if (red) 0xFFE53935.toInt() else pal.mut, R.drawable.ic_call, { Phone.call(this, c.number) }) { Phone.call(this, c.number) }
        }
        list.adapter = lad
        col.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        return col
    }

    // ---------- ردیف‌ها ----------
    private fun styleTabs() = tabText.forEachIndexed { i, tx ->
        tx.setTextColor(if (i == filter) pal.acc else pal.mut); tabInd[i].setBackgroundColor(if (i == filter) pal.acc else 0)
    }

    private fun render() {
        val s = searchBox.text.toString().trim()
        var l = all.filter {
            val arch = ChatPrefs.has(this, "arch", Sms.key(it.addr))
            when (filter) { 1 -> it.unread > 0 && !arch; 2 -> arch; else -> !arch }
        }
        if (s.isNotEmpty()) l = l.filter { it.name.contains(s, true) || it.addr.contains(s) || it.last.contains(s, true) }
        ad.items = l.sortedByDescending { ChatPrefs.has(this, "pin", Sms.key(it.addr)) }
        ad.notifyDataSetChanged()
    }

    private fun time(d: Long) = if (DateUtils.isToday(d)) fmt.format(Date(d)) else fmtD.format(Date(d))

    private fun divider() = View(this).apply { setBackgroundColor(pal.line); layoutParams = LinearLayout.LayoutParams(-1, 1).apply { marginStart = dp(72) } }

    private fun small(res: Int, tint: Int, w: Int, h: Int, m: Int = 0) = ImageView(this).apply {
        setImageResource(res); setColorFilter(tint); layoutParams = LinearLayout.LayoutParams(dp(w), dp(h)).apply { marginStart = dp(m); marginEnd = dp(m) }
    }

    private fun item(name: String, sub: String, subColor: Int, right: Int, onClick: () -> Unit, onRight: () -> Unit): View {
        val w = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setOnClickListener { onClick() } }
        val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(13), dp(9), dp(8), dp(9)) }
        r.addView(tgAvatar(name, 52, 20f))
        val t = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(7), 0, dp(7), 0) }
        t.addView(tv(name, 17f, pal.ink, true).apply { setSingleLine() })
        t.addView(tv(sub, 14f, subColor).apply { setSingleLine(); ellipsize = TextUtils.TruncateAt.END; textDirection = View.TEXT_DIRECTION_LOCALE })
        r.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(icon(right, pal.mut, onRight))
        w.addView(r); w.addView(divider())
        return w
    }

    /** ردیف گفتگو، مثل DialogCell تلگرام: ارتفاع ~۷۰، آواتار ۵۲، متن از ۷۲dp */
    private fun row(c: Conv): View {
        val k = Sms.key(c.addr); val pin = ChatPrefs.has(this, "pin", k); val mute = ChatPrefs.has(this, "mute", k)
        val w = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setOnClickListener { open(c.addr) }; setOnLongClickListener { chatMenu(c); true } }
        val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(13), dp(9), dp(14), dp(9)) }
        r.addView(tgAvatar(c.name, 52, 20f))
        val t = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(7), 0, 0, 0) }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(tv(c.name, 17f, pal.ink, true).apply { setSingleLine(); ellipsize = TextUtils.TruncateAt.END }, LinearLayout.LayoutParams(0, -2, 1f))
        if (mute) top.addView(small(R.drawable.ic_mute, pal.mut, 16, 16, 3))
        if (c.mine) top.addView(small(R.drawable.ic_checks, pal.tick, 18, 14, 3))
        top.addView(tv(time(c.date), 13f, pal.mut))
        t.addView(top)
        val bot = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        bot.addView(tv(c.last, 16f, pal.mut).apply { setSingleLine(); ellipsize = TextUtils.TruncateAt.END }, LinearLayout.LayoutParams(0, -2, 1f))
        if (c.unread > 0) bot.addView(tv(c.unread.toString(), 13f, WHITE, true).apply {
            gravity = Gravity.CENTER; minWidth = dp(22); setPadding(dp(7), dp(1), dp(7), dp(1))
            background = GradientDrawable().apply { cornerRadius = dp(11).toFloat(); setColor(if (mute) 0xFFBEC3C7.toInt() else pal.acc) }
        }) else if (pin) bot.addView(small(R.drawable.ic_pin, 0xFF919294.toInt(), 18, 18, 2))
        t.addView(bot, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) })
        r.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        w.addView(r); w.addView(divider())
        return w
    }

    private fun chatMenu(c: Conv) {
        val k = Sms.key(c.addr)
        fun lab(list: String, on: String, off: String) = if (ChatPrefs.has(this, list, k)) off else on
        val items = arrayOf(
            lab("pin", L.t("سنجاق کردن", "Pin"), L.t("برداشتن سنجاق", "Unpin")),
            lab("mute", L.t("بی‌صدا", "Mute"), L.t("با صدا", "Unmute")),
            lab("arch", L.t("آرشیو", "Archive"), L.t("خارج از آرشیو", "Unarchive")),
            L.t("حذف گفتگو", "Delete conversation")
        )
        AlertDialog.Builder(this).setItems(items) { _, i ->
            when (i) {
                0 -> ChatPrefs.toggle(this, "pin", k)
                1 -> ChatPrefs.toggle(this, "mute", k)
                2 -> ChatPrefs.toggle(this, "arch", k)
                else -> if (Sms.isDefault(this)) AlertDialog.Builder(this).setMessage(L.t("این گفتگو حذف شود؟", "Delete this conversation?"))
                    .setPositiveButton(L.t("حذف", "Delete")) { _, _ -> Sms.deleteThread(this, c.addr); refresh() }
                    .setNegativeButton(L.t("بستن", "Close"), null).show()
                else toast(L.t("برای حذف، اپ را پیامک پیش‌فرض کن", "Set the app as default SMS app to delete"))
            }
            render()
        }.show()
    }

    private fun newChat() {
        val e = EditText(this).apply { hint = L.t("شماره", "Number"); inputType = InputType.TYPE_CLASS_PHONE; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        AlertDialog.Builder(this).setTitle(L.t("گفتگوی جدید", "New conversation")).setView(e)
            .setPositiveButton(L.t("شروع", "Start")) { _, _ -> if (e.text.isNotBlank()) open(e.text.toString().trim()) }
            .setNegativeButton(L.t("بستن", "Close"), null).show()
    }

    private fun langDialog() {
        val v = listOf("auto", "fa", "en")
        AlertDialog.Builder(this).setTitle(L.t("زبان", "Language"))
            .setItems(arrayOf(L.t("خودکار", "Auto"), "فارسی", "English")) { _, i -> L.set(this, v[i]); recreate() }.show()
    }

    private fun open(a: String) = startActivity(Intent(this, ChatActivity::class.java).putExtra("addr", a))
}
