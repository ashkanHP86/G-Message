package com.example.reactapp

import android.content.Intent
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.InputType
import android.text.TextUtils
import android.text.format.DateUtils
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.core.widget.doAfterTextChanged
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Base() {
    private lateinit var content: FrameLayout
    private val pages = mutableListOf<View>()
    private val navIcon = mutableListOf<TextView>()
    private val navText = mutableListOf<TextView>()
    private var tab = 0
    private lateinit var q: EditText
    private lateinit var banner: TextView
    private lateinit var dialBanner: TextView
    private lateinit var ad: Ad<Conv>
    private lateinit var cad: Ad<Contact>
    private lateinit var lad: Ad<CallRow>
    private var all = listOf<Conv>()
    private val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val fmtD = SimpleDateFormat("MM/dd", Locale.getDefault())
    private val white = WHITE

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        content = FrameLayout(this)
        pages.add(messagesView()); pages.add(contactsView()); pages.add(callsView()); pages.add(moreView())
        pages.forEach { content.addView(it) }
        val nav = LinearLayout(this).apply { setBackgroundColor(pal.soft); setPadding(0, dp(6), 0, dp(6)) }
        listOf(L.t("پیام‌ها", "Messages") to "💬", L.t("مخاطبین", "Contacts") to "👤", L.t("تماس‌ها", "Calls") to "📞", L.t("بیشتر", "More") to "☰").forEachIndexed { i, (t, ic) ->
            val icon = tv(ic, 20f, pal.mut).apply { gravity = Gravity.CENTER; setPadding(dp(14), dp(6), dp(14), dp(6)) }
            val txt = tv(t, 11f, pal.mut).apply { gravity = Gravity.CENTER }
            navIcon.add(icon); navText.add(txt)
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(0, dp(4), 0, dp(4))
                addView(icon); addView(txt); setOnClickListener { select(i) }
            }
            nav.addView(cell, LinearLayout.LayoutParams(0, -2, 1f))
        }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(pal.bg) }
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(nav, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
        select(0)
    }

    private fun select(i: Int) {
        tab = i
        pages.forEachIndexed { k, v -> v.visibility = if (k == i) View.VISIBLE else View.GONE }
        for (k in 0..3) {
            val on = k == i
            val c = if (on) pal.acc else pal.mut
            navIcon[k].setTextColor(c); navText[k].setTextColor(c)
            navIcon[k].background = if (on) box(pal.accSoft(), 14) else null
        }
        refresh()
    }

    override fun refresh() {
        if (!::content.isInitialized) return
        banner.visibility = if (Sms.isDefault(this)) View.GONE else View.VISIBLE
        dialBanner.visibility = if (Phone.isDialer(this)) View.GONE else View.VISIBLE
        when (tab) {
            0 -> { all = Sms.conversations(this); render() }
            1 -> { cad.items = Phone.contacts(this); cad.notifyDataSetChanged() }
            2 -> { lad.items = Phone.callLog(this); lad.notifyDataSetChanged() }
        }
    }

    // ---------- ساختار صفحه‌ها ----------
    private fun page(title: String) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(20), dp(16), 0)
        addView(tv(title, 28f, pal.ink, true))
    }

    private fun listV() = ListView(this).apply {
        divider = null; selector = ColorDrawable(0); clipToPadding = false; setPadding(0, dp(8), 0, dp(90))
    }

    private fun bannerV(text: String, click: () -> Unit) = tv(text, 13f, white, true).apply {
        background = grad(pal.acc, pal.acc2, 14); setPadding(dp(14), dp(10), dp(14), dp(10)); setOnClickListener { click() }
    }

    private fun fab(icon: String, click: () -> Unit) = circle(icon, grad(pal.acc, pal.acc2, 20), 58, 26f, white, click)
    private fun fabLp() = FrameLayout.LayoutParams(dp(58), dp(58), Gravity.BOTTOM or (if (L.fa) Gravity.START else Gravity.END)).apply { setMargins(dp(20), 0, dp(20), dp(24)) }
    private val top12 get() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) }

    private fun messagesView(): View {
        val root = FrameLayout(this)
        val col = page(L.t("پیام‌ها", "Messages"))
        banner = bannerV(L.t("برای دریافت و ذخیره‌ی کامل پیامک‌ها، این اپ را پیامک پیش‌فرض کن  ›", "Make this app your default SMS app  ›")) { Sms.askDefault(this) }
        q = EditText(this).apply {
            hint = "🔍  " + L.t("جستجو در گفتگوها", "Search conversations"); textSize = 15f; setTextColor(pal.ink); setHintTextColor(pal.mut)
            background = box(pal.soft, 16); setPadding(dp(16), dp(12), dp(16), dp(12)); setSingleLine()
            doAfterTextChanged { render() }
        }
        val list = listV()
        ad = Ad(listOf()) { c -> row(c) }
        list.adapter = ad
        col.addView(banner, top12); col.addView(q, top12)
        col.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(col)
        root.addView(fab("＋") { newChat() }, fabLp())
        return root
    }

    private fun contactsView(): View {
        val col = page(L.t("مخاطبین", "Contacts"))
        val list = listV()
        cad = Ad(listOf()) { c -> item(c.name, c.number, pal.mut, "📞", { open(c.number) }) { Phone.call(this, c.number) } }
        list.adapter = cad
        col.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        return col
    }

    private fun callsView(): View {
        val root = FrameLayout(this)
        val col = page(L.t("تماس‌ها", "Calls"))
        dialBanner = bannerV(L.t("برای نمایش صفحه‌ی تماس در این اپ، آن را برنامه‌ی تماس پیش‌فرض کن  ›", "Make this app your default phone app  ›")) { Phone.askDialer(this) }
        val list = listV()
        lad = Ad(listOf()) { c ->
            val (lbl, red) = when (c.type) { 1 -> L.t("↙ ورودی", "↙ Incoming") to false; 2 -> L.t("↗ خروجی", "↗ Outgoing") to false; else -> L.t("✕ بی‌پاسخ", "✕ Missed") to true }
            item(c.name, "$lbl • ${time(c.date)}", if (red) 0xFFE53935.toInt() else pal.mut, "📞", { Phone.call(this, c.number) }) { Phone.call(this, c.number) }
        }
        list.adapter = lad
        col.addView(dialBanner, top12)
        col.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(col)
        root.addView(fab("⌗") { startActivity(Intent(this, DialerActivity::class.java)) }, fabLp())
        return root
    }

    private fun moreView(): View {
        val col = page(L.t("بیشتر", "More"))
        fun menu(t: String, go: () -> Unit) = col.addView(
            tv(t, 16f, pal.ink, true).apply { background = box(pal.soft, 16); setPadding(dp(18), dp(16), dp(18), dp(16)); setOnClickListener { go() } },
            top12
        )
        menu(L.t("⚙️  تنظیمات ری‌اکشن", "⚙️  Reaction settings")) { startActivity(Intent(this, SettingsActivity::class.java)) }
        menu(L.t("💬  پیامک پیش‌فرض", "💬  Default SMS app")) { Sms.askDefault(this) }
        menu(L.t("📞  برنامه‌ی تماس پیش‌فرض", "📞  Default phone app")) { Phone.askDialer(this) }
        menu(L.t("🌐  زبان", "🌐  Language")) { langDialog() }
        return col
    }

    // ---------- ردیف‌ها ----------
    private fun render() {
        val s = q.text.toString().trim()
        ad.items = if (s.isEmpty()) all else all.filter { it.name.contains(s, true) || it.addr.contains(s) || it.last.contains(s, true) }
        ad.notifyDataSetChanged()
    }

    private fun time(d: Long) = if (DateUtils.isToday(d)) fmt.format(Date(d)) else fmtD.format(Date(d))

    private fun avatar(name: String): View {
        val cols = intArrayOf(0xFF5B4BFF.toInt(), 0xFF0D9488.toInt(), 0xFFDB2777.toInt(), 0xFFD97706.toInt(), 0xFF2563EB.toInt())
        return circle(name.firstOrNull { it.isLetter() }?.uppercase() ?: "#", box(cols[Math.abs(name.hashCode()) % cols.size], 18), 50, 18f, white)
    }

    private fun card(inner: View): View = LinearLayout(this).apply { setPadding(0, 0, 0, dp(8)); addView(inner) }

    private fun item(name: String, sub: String, subColor: Int, right: String, onClick: () -> Unit, onRight: () -> Unit): View {
        val r = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; background = box(pal.soft, 18); setPadding(dp(10), dp(10), dp(10), dp(10)); setOnClickListener { onClick() }
        }
        r.addView(avatar(name))
        val t = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(12), 0) }
        t.addView(tv(name, 16f, pal.ink, true).apply { setSingleLine() })
        t.addView(tv(sub, 13f, subColor).apply { setSingleLine(); ellipsize = TextUtils.TruncateAt.END; textDirection = View.TEXT_DIRECTION_LOCALE })
        r.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(circle(right, box(pal.inb, 20), 40, 16f, pal.ink) { onRight() })
        return card(r)
    }

    private fun row(c: Conv): View {
        val r = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; background = box(pal.soft, 18); setPadding(dp(10), dp(10), dp(10), dp(10)); setOnClickListener { open(c.addr) }
        }
        r.addView(avatar(c.name))
        val t = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(12), 0) }
        val top = LinearLayout(this)
        top.addView(tv(c.name, 16f, pal.ink, true).apply { setSingleLine() }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(tv(time(c.date), 12f, pal.acc, true))
        t.addView(top)
        t.addView(tv((if (c.mine) L.t("تو: ", "You: ") else "") + c.last, 14f, pal.mut).apply { setSingleLine(); ellipsize = TextUtils.TruncateAt.END })
        r.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        return card(r)
    }

    private fun newChat() {
        val e = EditText(this).apply { hint = L.t("شماره", "Number"); inputType = InputType.TYPE_CLASS_PHONE; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        AlertDialog.Builder(this).setTitle(L.t("گفتگوی جدید", "New conversation")).setView(e)
            .setPositiveButton(L.t("شروع", "Start")) { _, _ -> if (e.text.isNotBlank()) open(e.text.toString().trim()) }
            .setNegativeButton(L.t("بستن", "Close"), null).show()
    }

    private fun langDialog() {
        val v = listOf("auto", "fa", "en")
        AlertDialog.Builder(this).setTitle(L.t("زبان", "Language"))
            .setItems(arrayOf(L.t("خودکار", "Auto"), "فارسی", "English")) { _, i -> L.set(this, v[i]); recreate() }.show()
    }

    private fun open(a: String) = startActivity(Intent(this, ChatActivity::class.java).putExtra("addr", a))
}
