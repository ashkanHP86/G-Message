package com.example.reactapp

import android.content.Context

/** تنظیمات ظاهر: حالت، رنگ، پس‌زمینه، اندازه‌ی متن */
object Theme {
    val accents = intArrayOf(0xFF229AF0.toInt(), 0xFF5B4BFF.toInt(), 0xFF2EAD4F.toInt(), 0xFFE91E8C.toInt(), 0xFFFF9800.toInt())
    var scale = 1f
    private fun p(c: Context) = c.getSharedPreferences("theme", 0)
    fun mode(c: Context) = p(c).getString("mode", "auto") ?: "auto"
    fun accent(c: Context) = p(c).getInt("accent", 0)
    fun wall(c: Context) = p(c).getInt("wall", 1)
    fun size(c: Context) = p(c).getString("size", "m") ?: "m"
    fun set(c: Context, k: String, v: Any) {
        val e = p(c).edit()
        if (v is Int) e.putInt(k, v) else e.putString(k, v.toString())
        e.apply()
    }
    fun init(c: Context) { scale = when (size(c)) { "s" -> 0.9f; "l" -> 1.15f; else -> 1f } }
    fun key(c: Context) = mode(c) + accent(c) + wall(c) + size(c) + L.fa
}
