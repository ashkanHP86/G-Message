package com.example.reactapp

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.format.DateUtils
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.PopupWindow
import androidx.appcompat.app.AlertDialog
import androidx.core.widget.doAfterTextChanged
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class ChatActivity : Base() {
    private lateinit var addr: String
    private lateinit var ad: Ad<Msg>
    private lateinit var list: ListView
    private lateinit var input: EditText
    private lateinit var sendIc: ImageView
    private var lastCount = -1
    private val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val grey = 0xFF8E959B.toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        addr = intent.getStringExtra("addr")
            ?: intent.data?.schemeSpecificPart?.substringBefore('?')?.takeIf { it.isNotBlank() }
            ?: run { finish(); return }
        val name = Sms.name(this, addr)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(pal.bg) }

        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(pal.bar); setPadding(dp(4), dp(4), dp(4), dp(4)); elevation = dp(2).toFloat() }
        bar.addView(icon(R.drawable.ic_back, pal.ink) { finish() }.apply { scaleX = if (L.fa) -1f else 1f })
        bar.addView(tgAvatar(name, 40, 16f), LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginStart = dp(4) })
        val ht = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(8), 0) }
        ht.addView(tv(name, 17f, pal.ink, true).apply { setSingleLine() })
        ht.addView(tv(addr, 13f, pal.mut).apply { textDirection = View.TEXT_DIRECTION_LTR })
        bar.addView(ht, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(icon(R.drawable.ic_call, pal.ink) { Phone.call(this, addr) })
        bar.addView(icon(R.drawable.ic_more, pal.ink) { chatMore() })

        list = ListView(this).apply {
            divider = null; selector = ColorDrawable(0); clipToPadding = false; setPadding(dp(8), dp(6), dp(8), dp(6)); background = pal.wall()
        }
        ad = Ad(listOf()) { m -> bubble(m) }
        list.adapter = ad

        val bar2 = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(pal.bar); setPadding(dp(4), dp(2), dp(4), dp(2)) }
        bar2.addView(icon(R.drawable.ic_emoji, grey) { input.requestFocus() })
        input = EditText(this).apply {
            hint = L.t("پیام", "Message"); textSize = 16f * Theme.scale; setTextColor(pal.ink); setHintTextColor(0xFF858A84.toInt())
            background = null; maxLines = 5; setPadding(dp(4), dp(12), dp(4), dp(12)); doAfterTextChanged { updateSend() }
        }
        bar2.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        bar2.addView(icon(R.drawable.ic_attach, grey) { toast(L.t("ارسال فایل (MMS) هنوز پشتیبانی نمی‌شود", "Attachments (MMS) aren't supported yet")) })
        sendIc = icon(R.drawable.ic_mic, grey) {
            if (input.text.isNotBlank()) send() else toast(L.t("پیام صوتی روی پیامک ممکن نیست", "Voice messages aren't possible over SMS"))
        }
        bar2.addView(sendIc)

        root.addView(bar)
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(bar2)
        setContentView(root)
    }

    private fun updateSend() {
        val has = input.text.isNotBlank()
        sendIc.setImageResource(if (has) R.drawable.ic_send else R.drawable.ic_mic)
        sendIc.setColorFilter(if (has) pal.acc else grey)
        sendIc.scaleX = if (has && L.fa) -1f else 1f
    }

    override fun refresh() {
        if (!::ad.isInitialized) return
        Sms.markRead(this, addr)
        ad.items = Sms.thread(this, addr)
        ad.notifyDataSetChanged()
        if (ad.count != lastCount) { list.setSelection(ad.count - 1); lastCount = ad.count }
    }

    private fun bubble(m: Msg): View {
        val w = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(2), 0, dp(2)) }
        val prev = ad.items.getOrNull(ad.items.indexOf(m) - 1)
        if (prev == null || dayOf(prev.date) != dayOf(m.date)) w.addView(
            tv(dayLabel(m.date), 13f, WHITE, true).apply { gravity = Gravity.CENTER; background = box(0x66000000, 14); setPadding(dp(12), dp(3), dp(12), dp(3)) },
            LinearLayout.LayoutParams(-2, -2).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(8); bottomMargin = dp(8) }
        )
        val g = if (m.mine == L.fa) Gravity.START else Gravity.END
        val b = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = bubbleBg(if (m.mine) pal.outb else pal.inb, m.mine)
            setPadding(dp(10), dp(6), dp(10), dp(5)); setOnLongClickListener { pop(this, m); true }
        }
        b.addView(tv(m.body, 16f, pal.ink).apply { maxWidth = (resources.displayMetrics.widthPixels * 0.74).toInt() })
        val meta = LinearLayout(this).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL }
        meta.addView(tv(fmt.format(Date(m.date)), 12f, if (m.mine) pal.outTime else pal.inTime))
        if (m.mine) meta.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_checks); setColorFilter(pal.tick)
            layoutParams = LinearLayout.LayoutParams(dp(17), dp(14)).apply { marginStart = dp(3) }
        })
        b.addView(meta, LinearLayout.LayoutParams(-1, -2))
        w.addView(b, LinearLayout.LayoutParams(-2, -2).apply { gravity = g })
        if (m.rx.isNotEmpty()) {
            val rr = LinearLayout(this)
            for (r in m.rx) rr.addView(
                tv(r.e ?: Rx.emoji(this, r.k), 14f, pal.ink).apply {
                    background = box(pal.bg, 12, if (r.me) 2 else 1, if (r.me) pal.acc else pal.line)
                    setPadding(dp(8), dp(1), dp(8), dp(1))
                    if (r.me && r.k >= 0) setOnClickListener { toggle(m, r.k) }
                },
                LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(4) }
            )
            w.addView(rr, LinearLayout.LayoutParams(-2, -2).apply { gravity = g; topMargin = -dp(6); marginStart = dp(8); marginEnd = dp(8) })
        }
        return w
    }

    private fun dayOf(d: Long) = (d + TimeZone.getDefault().getOffset(d)) / 86400000L

    private fun dayLabel(d: Long) = when {
        DateUtils.isToday(d) -> L.t("امروز", "Today")
        DateUtils.isToday(d + 86400000L) -> L.t("دیروز", "Yesterday")
        else -> SimpleDateFormat("MMM d", Locale.getDefault()).format(Date(d))
    }

    private fun delete(m: Msg) {
        if (!Sms.isDefault(this)) { toast(L.t("برای حذف، اپ را پیامک پیش‌فرض کن", "Set the app as default SMS app to delete")); return }
        Sms.deleteMessage(this, m); refresh()
    }

    private fun chatMore() {
        val k = Sms.key(addr)
        val muted = ChatPrefs.has(this, "mute", k)
        AlertDialog.Builder(this).setItems(arrayOf(if (muted) L.t("با صدا", "Unmute") else L.t("بی‌صدا", "Mute"), L.t("حذف گفتگو", "Delete conversation"))) { _, i ->
            if (i == 0) ChatPrefs.toggle(this, "mute", k)
            else if (Sms.isDefault(this)) { Sms.deleteThread(this, addr); finish() }
            else toast(L.t("برای حذف، اپ را پیامک پیش‌فرض کن", "Set the app as default SMS app to delete"))
        }.show()
    }

    private fun pop(anchor: View, m: Msg) {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = box(pal.bg, 22, 1, pal.line); setPadding(dp(8), dp(6), dp(8), dp(6)) }
        val pw = PopupWindow(col, -2, -2, true)
        pw.elevation = dp(10).toFloat()
        pw.setBackgroundDrawable(ColorDrawable(0))
        val row = LinearLayout(this)
        for (k in Rx.types.indices) {
            if (!Rx.enabled(this, k)) continue
            val mine = m.rx.any { it.k == k && it.me }
            row.addView(circle(Rx.emoji(this, k), box(if (mine) pal.soft else 0, 22), 44, 24f, pal.ink) { pw.dismiss(); toggle(m, k) })
        }
        col.addView(row)
        val acts = listOf(
            L.t("کپی", "Copy") to { getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("msg", m.body)); toast(L.t("کپی شد", "Copied")) },
            L.t("ارسال به…", "Forward") to { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, m.body), null)) },
            L.t("حذف", "Delete") to { delete(m) }
        )
        for ((t, f) in acts) col.addView(tv(t, 15f, pal.ink).apply { setPadding(dp(12), dp(10), dp(12), dp(10)); setOnClickListener { pw.dismiss(); f() } })
        col.measure(0, 0)
        pw.showAsDropDown(anchor, (anchor.width - col.measuredWidth) / 2, -(anchor.height + col.measuredHeight + dp(6)))
    }

    /** هر ری‌اکشن فقط یک بار؛ زدن دوباره = حذف */
    private fun toggle(m: Msg, k: Int) {
        val has = m.rx.any { it.k == k && it.me }
        if (!Sms.send(this, addr, if (has) Rx.textRemove(k, m.body) else Rx.textAdd(k, m.body))) { toast(L.t("ارسال نشد", "Not sent")); return }
        if (has) m.rx.removeAll { it.k == k && it.me } else m.rx.add(Rc(k, true))
        ad.notifyDataSetChanged()
    }

    private fun send() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        if (Sms.send(this, addr, t)) { input.setText(""); refresh() } else toast(L.t("ارسال نشد", "Not sent"))
    }
}
