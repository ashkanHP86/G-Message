package com.example.reactapp

import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.PopupWindow
import androidx.appcompat.app.AlertDialog
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ChatActivity : Base() {
    private lateinit var addr: String
    private lateinit var ad: Ad<Msg>
    private lateinit var list: ListView
    private lateinit var input: EditText
    private var lastCount = -1
    private val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        addr = intent.getStringExtra("addr")
            ?: intent.data?.schemeSpecificPart?.substringBefore('?')?.takeIf { it.isNotBlank() }
            ?: run { finish(); return }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(pal.bg) }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(14), dp(16), dp(12)) }
        head.addView(circle(if (L.fa) "›" else "‹", box(pal.soft, 21), 42, 22f, pal.ink) { finish() })
        val ht = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        ht.addView(tv(Sms.name(this, addr), 17f, pal.ink, true))
        ht.addView(tv(addr, 12f, pal.mut).apply { textDirection = View.TEXT_DIRECTION_LTR })
        head.addView(ht, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(circle("🗑", box(pal.soft, 21), 42, 18f, pal.ink) { confirmClear() })

        list = ListView(this).apply {
            divider = null; selector = ColorDrawable(0); clipToPadding = false; setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        ad = Ad(listOf()) { m -> bubble(m) }
        list.adapter = ad

        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(12)) }
        input = EditText(this).apply {
            hint = L.t("پیام بنویس", "Type a message"); textSize = 15f; setTextColor(pal.ink); setHintTextColor(pal.mut)
            background = box(pal.soft, 26); setPadding(dp(18), dp(12), dp(18), dp(12)); maxLines = 4
        }
        bar.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(
            circle("➤", grad(pal.acc, pal.acc2, 23), 46, 18f, WHITE) { send() }.apply { scaleX = if (L.fa) -1f else 1f },
            LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginStart = dp(8) }
        )
        root.addView(head)
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(bar)
        setContentView(root)
    }

    override fun refresh() {
        if (!::ad.isInitialized) return
        ad.items = Sms.thread(this, addr)
        ad.notifyDataSetChanged()
        if (ad.count != lastCount) { list.setSelection(ad.count - 1); lastCount = ad.count }
    }

    private fun bubble(m: Msg): View {
        val w = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(3), 0, dp(5)) }
        val g = if (m.mine == L.fa) Gravity.START else Gravity.END
        val t = tv(m.body, 16f, if (m.mine) WHITE else pal.ink).apply {
            background = if (m.mine) grad(pal.acc, pal.acc2, 22) else box(pal.inb, 22)
            setPadding(dp(16), dp(10), dp(16), dp(10))
            maxWidth = (resources.displayMetrics.widthPixels * 0.78).toInt()
            setOnLongClickListener { pop(this, m); true }
        }
        w.addView(t, LinearLayout.LayoutParams(-2, -2).apply { gravity = g })
        if (m.rx.isNotEmpty()) {
            val rr = LinearLayout(this)
            for (r in m.rx) rr.addView(
                tv(r.e ?: Rx.emoji(this, r.k), 14f, pal.ink).apply {
                    background = box(pal.bg, 12, if (r.me) 2 else 1, if (r.me) pal.acc else pal.soft)
                    setPadding(dp(8), dp(1), dp(8), dp(1))
                    if (r.me) setOnClickListener { if (r.k >= 0) toggle(m, r.k) else r.e?.let { e -> toggleCustom(m, e) } }
                },
                LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(4) }
            )
            w.addView(rr, LinearLayout.LayoutParams(-2, -2).apply { gravity = g; topMargin = -dp(8); marginStart = dp(8); marginEnd = dp(8) })
        }
        w.addView(tv(fmt.format(Date(m.date)), 11f, pal.mut), LinearLayout.LayoutParams(-2, -2).apply { gravity = g; marginStart = dp(8); marginEnd = dp(8) })
        return w
    }

    private fun pop(anchor: View, m: Msg) {
        val row = LinearLayout(this).apply { setPadding(dp(8), dp(6), dp(8), dp(6)) }
        val scroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            background = box(pal.bg, 30, 1, pal.soft)
            addView(row)
        }
        val pw = PopupWindow(scroll, -2, -2, true)
        pw.elevation = dp(10).toFloat()
        pw.setBackgroundDrawable(ColorDrawable(0))
        for (k in Rx.types.indices) {
            if (!Rx.enabled(this, k)) continue
            val mine = m.rx.any { it.k == k && it.me }
            row.addView(circle(Rx.emoji(this, k), box(if (mine) pal.soft else 0, 22), 44, 24f, pal.ink) { pw.dismiss(); toggle(m, k) })
        }
        row.addView(circle("+", box(0, 22), 44, 22f, pal.mut) {
            pw.dismiss(); customReactionDialog(m)
        }, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginStart = dp(4) })
        row.addView(circle("🗑", box(0, 22), 44, 20f, 0xFFE53935.toInt()) {
            pw.dismiss(); confirmDeleteMessage(m)
        }, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginStart = dp(4) })
        row.measure(0, 0)
        val w = row.measuredWidth.coerceAtMost(dp(280))
        pw.width = w
        pw.showAsDropDown(anchor, (anchor.width - w) / 2, -(anchor.height + row.measuredHeight + dp(6)))
    }

    private fun customReactionDialog(m: Msg) {
        val et = EditText(this).apply { hint = L.t("یک ایموجی بفرست", "Send an emoji"); textSize = 22f }
        AlertDialog.Builder(this).setTitle(L.t("ری‌اکشن سفارشی", "Custom reaction")).setView(et)
            .setPositiveButton(L.t("ارسال", "Send")) { _, _ ->
                Rx.firstChar(et.text.toString())?.let { toggleCustom(m, it) }
            }
            .setNegativeButton(L.t("بستن", "Close"), null).show()
    }

    private fun confirmDeleteMessage(m: Msg) {
        AlertDialog.Builder(this).setTitle(L.t("حذف پیام", "Delete message"))
            .setMessage(L.t("این پیام حذف شود؟", "Delete this message?"))
            .setPositiveButton(L.t("حذف", "Delete")) { _, _ -> Sms.delete(this, addr, m); refresh() }
            .setNegativeButton(L.t("انصراف", "Cancel"), null).show()
    }

    private fun confirmClear() {
        AlertDialog.Builder(this).setTitle(L.t("پاک کردن گفتگو", "Clear conversation"))
            .setMessage(L.t("همه‌ی پیام‌های این گفتگو حذف شوند؟", "Delete all messages in this conversation?"))
            .setPositiveButton(L.t("پاک کن", "Clear")) { _, _ -> Sms.clearThread(this, addr); refresh() }
            .setNegativeButton(L.t("انصراف", "Cancel"), null).show()
    }

    /** هر ری‌اکشن فقط یک بار؛ زدن دوباره = حذف */
    private fun toggle(m: Msg, k: Int) {
        val has = m.rx.any { it.k == k && it.me }
        if (!Sms.send(this, addr, if (has) Rx.textRemove(k, m.body) else Rx.textAdd(k, m.body))) { toast(L.t("ارسال نشد", "Not sent")); return }
        if (has) m.rx.removeAll { it.k == k && it.me } else m.rx.add(Rc(k, true))
        ad.notifyDataSetChanged()
    }

    /** ری‌اکشن با ایموجی دلخواه (خارج از ۶ نوع استاندارد) */
    private fun toggleCustom(m: Msg, emoji: String) {
        val has = m.rx.any { it.k == -1 && it.e == emoji && it.me }
        if (!Sms.send(this, addr, if (has) Rx.textRemoveCustom(emoji, m.body) else Rx.textAddCustom(emoji, m.body))) { toast(L.t("ارسال نشد", "Not sent")); return }
        if (has) m.rx.removeAll { it.k == -1 && it.e == emoji && it.me } else m.rx.add(Rc(-1, true, emoji))
        ad.notifyDataSetChanged()
    }

    private fun send() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        if (Sms.send(this, addr, t)) { input.setText(""); refresh() } else toast(L.t("ارسال نشد", "Not sent"))
    }
}
